import React from 'react'
import './Userhome.css' 
import Logo from '../../../assets/Logo.jpeg'
import userlogo from '../../../assets/userlogo.jpg'
import Footer from '../../../Component/Footer/Footer'
export default function Userhome() {
  return (
    <>
    <nav className='nav-container'>
    
            <div className='image-container'>
                <img src={Logo} alt="Logo" className='logo' />
            </div> 
    
            <div className='title-container'>
                <h1> LIBRARY MANAGEMENT SYSTEM </h1>
            </div>

            <div className="logout-container">
        <button className="logout-btn">
            Logout
        </button>
    </div>
            
        </nav>
    <div className="userhome-container">

    <img
        src={userlogo}
        alt="User Logo"
        className="home-image"
    />

    <div className="overlay">

        <div className="overlay-content">

            <h1>Welcome to the Library Management System</h1>

            <p>
                Discover books, manage borrowings, and explore your library easily.
            </p>

            <div className="button-group">

                <a href="/books" className="btn">
                    Explore Books
                </a>

                <a href="/borrowed" className="btn secondary-btn">
                    My Borrowed Books
                </a>

            </div>

            <input
                type="text"
                placeholder="Search for books..."
                className="search-bar"
            />

        </div>

    </div>

</div>
    <Footer />
    </>
  )
}
