import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import './Login.css'
import Navbar from '../../Component/Navbar/Navbar'
import Footer from '../../Component/Footer/Footer'

export default function Login() {

  const navigate = useNavigate()

  const [username, setUsername] = useState('')

  const [password, setPassword] = useState('')

  const handleLogin = (e) => {

    e.preventDefault()

    // Admin Login
    if (
      username === 'admin' &&
      password === 'admin123'
    ) {

      navigate('/admin-home')
    }

    // User Login
    else if (

      (username === 'Shyam' &&
      password === 'shyam123')

      ||

      (username === 'Priya' &&
      password === 'priya123')

    ) {

      navigate('/user-home')
    }

    else {

      alert('Invalid Username or Password')
    }
  }

  return (
    <>
      <Navbar />  

      <div className="login-container">

        <form
          className="login-form"
          onSubmit={handleLogin}
        >

          <h1>Login</h1>

          <input
            type="text"
            placeholder="Enter Username"
            value={username}
            onChange={(e) =>
              setUsername(e.target.value)
            }
          />

          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) =>
              setPassword(e.target.value)
            }
          />

          <button type="submit">
            Login
          </button>

        </form>

      </div>
      <Footer />
    </>
  )
}