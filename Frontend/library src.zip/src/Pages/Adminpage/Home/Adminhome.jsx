import React from 'react'
import './Adminhome.css'
import Navbar from '../../../Component/Navbar/Navbar'   
import Footer from '../../../Component/Footer/Footer'
import Adminlogo from '../../../assets/adminlogo.jpg'

export default function Adminhome() {
  return (
    <>
        <Navbar />
        <div>
            <img
                src={Adminlogo}
                alt="Admin Logo"
                className="admin-logo"
            />
            <h1 className="admin-welcome">Welcome, Admin!</h1>
        </div>
        <Footer />
    </>
  )
}
